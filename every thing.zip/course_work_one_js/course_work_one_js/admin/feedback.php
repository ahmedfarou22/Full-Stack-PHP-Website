<?php

session_start();

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname = "food_order"; /* Database name */

$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
?>

<?php
if(!isset($_SESSION['uname'])){
  header('Location: loginadmin.php');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/admin_style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>

<!-- =================================Head========================================= -->
<?php
include 'builder/nav.php';
include 'builder/hero.php';
?>


<!-- =============================================================Main Section=================================-->


    <!-- main section  -->
    <section class="action main">
      <div class="container">


       <br>
       <br>
       <h1>Manage Feedback </h1>
       <br>
       <br>

       
       <table class="full-tbl"> 
        <tr>
          <th>S.N</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Subject</th>
          <th>Actions</th>
        </tr>
        
        <!-- ------------------------------------------------------------------------------------------- -->
        <?php
         $dbhost = 'localhost';
         $dbuser = 'root';
         $dbpass = '';
         $dbname = 'food_order';
         $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
         $sql = 'SELECT * FROM menu_table';
         $result = mysqli_query($conn, $sql);

         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                $id = $row["id"]. "<br>";
                $first_name = $row["first_name"]. "<br>";
                $last_name = $row["last_name"]. "<br>";
                $email = $row["email"]. "<br>";
                $subject = $row["subject"]. "<br>";
                ?>

                <tr>
                <td><?php echo $id; ?>. </td>
                <td><?php echo $first_name; ?></td>
                <td><?php echo $last_name; ?></td>
                <td><?php echo $email; ?></td>
                <td><?php echo $subject; ?></td>
                <td><a href="execute_actions/delete_feedback_exe.php" class="btn" style="padding: 2.5%;"> Delete Feedback</a></td>
                </tr>
            
            <?php
            }
         } 
         mysqli_close($conn);
      ?>


        
       </table>
        

      

      </div>
      
      <div class="clear-fix"></div>
     
    </section>
    <!-- end of main  -->




<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>





</body>
</html>