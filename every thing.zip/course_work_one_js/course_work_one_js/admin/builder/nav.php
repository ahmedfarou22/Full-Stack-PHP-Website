<?php

    //  <!-- start of top nav --><!-- ---------------------------------------------------------------------------------------------------- -->
    echo'
    <section class="top_nav">
    <div class="container">
      <div class="logo">                
        <a href="http://localhost/course_work_one/" title="Logo">
        <img src="imges/logo.png" alt="Restaurant Logo" width="100%">
        </a>
      </div>
      
        <div class="menu-right">
        <ul>
          <li style="color:black; margin-right: 300px;">
              Welcome back  '  . $_SESSION['uname'] . '
          </li>

            <li>
                <a href="http://localhost/course_work_one/">Home</a>
            </li>
            <li>
                <a href="index.php">Admins</a>
            </li>
            <li>
                <a href="feedback.php">Feedback</a>
            </li>
            <li>
                <a href="orders.php">Orders</a>
            </li>
            <li>
            <a href="logout_s.php" class="logouts">Logout</a>
          </li>

        </ul>
        </div>
        



      <div class="clear-fix"></div>
    </div>
  </section>'
    //  <!-- end of top nav --><!-- ---------------------------------------------------------------------------------------------------- -->


?>