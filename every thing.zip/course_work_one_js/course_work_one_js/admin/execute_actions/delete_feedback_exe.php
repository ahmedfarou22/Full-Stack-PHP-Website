<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "food_order";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    }
           $sql = 'SELECT * FROM menu_table';
         $result = mysqli_query($conn, $sql);

         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                $id = $row["id"];
            }
         } 
      ?>


<?php
// sql to delete a record
$sql = "DELETE FROM menu_table WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>