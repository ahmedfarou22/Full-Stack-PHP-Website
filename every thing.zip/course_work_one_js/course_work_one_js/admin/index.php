<?php

session_start();

$host = "localhost"; 
$user = "root"; 
$password = ""; 
$dbname = "food_order"; 

$con = mysqli_connect($host, $user, $password,$dbname);
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
?>

<?php
// echo $_SESSION['uname'];
if(!isset($_SESSION['uname'])){
  header('Location: loginadmin.php');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/admin_style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>


<!-- =================================Head========================================= -->
<?php
include 'builder/nav.php';
include 'builder/hero.php';
?>


<!-- =============================================================Main Section=================================-->

    
    <!-- table section  -->
    <section class="action main">
      <div class="container">
       <h1>Manage Admins </h1>

       <br>
       <br>

       <a href="add_admin.php" class="btn" style="padding: 0.7%;">Add new admin</a>
       <br>
       <br>

       
       <table class="full-tbl"> 
        <tr>
          <th>S.N</th>
          <th>Username</th>
          <th>Name</th>
          <th>Actions</th>
        </tr>
      <!-- ------------------------------------------------------------------------------------------- -->
        <?php
         $dbhost = 'localhost';
         $dbuser = 'root';
         $dbpass = '';
         $dbname = 'food_order';
         $conn = mysqli_connect($dbhost, $dbuser, $dbpass,$dbname);
   
         $sql = 'SELECT * FROM users';
         $result = mysqli_query($conn, $sql);

         if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                $id = $row["id"]. "<br>";
                $username = $row["username"]. "<br>";
                $name = $row["name"]. "<br>";
                ?>

                <tr>
                <td><?php echo $id; ?>. </td>
                <td><?php echo $username; ?></td>
                <td><?php echo $name; ?></td>
                <td><a href="execute_actions/delete_admin_exe.php" class="btn" style="padding: 2.5%;"> Delete admin</a></td>
                </tr>
            
            <?php
            }
         } 
         mysqli_close($conn);
      ?>
        
       </table>
        

      

      </div>
      
      <div class="clear-fix"></div>
     
    </section>
    <!-- end of main  -->




<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>


</body>
</html>