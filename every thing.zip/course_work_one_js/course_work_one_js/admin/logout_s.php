<?php

session_start();

$host = "localhost"; 
$user = "root"; 
$password = ""; 
$dbname = "food_order"; 

$con = mysqli_connect($host, $user, $password,$dbname);
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
?>

<?php

  session_destroy();
  header('Location:loginadmin.php');

?>