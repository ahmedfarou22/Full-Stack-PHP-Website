<?php

session_start();

$host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname = "food_order"; /* Database name */

$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}
?>

<?php
if(!isset($_SESSION['uname'])){
  header('Location: loginadmin.php');
}
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/admin_style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>

<!-- =================================Head========================================= -->
<?php
include 'builder/nav.php';
include 'builder/hero.php';
?>


<!-- =============================================================Main Section=================================-->
    <!-- main section  -->
    <section class="action main">
      <div class="container">
        <h1>Add Admin</h1>
          <form action="add_admin.php" method="POST"> 
            <table>
             
            <tr>
                <td> <input type="text" name="username" placeholder="Enter admin Username"> </td>
              </tr>
              
              <tr>
                <td> <input type="text" name="name" placeholder="Enter admin Name"> </td>
              </tr>
             
              <tr>
                <td> <input type="text" name="password" placeholder=" Enter admin password"> </td>
              </tr>
            </table>

            <input type="submit" name="submit" value="Add Admin" class="btn" style="padding: 1%;">
          </form>
      </div>
      <div class="clear-fix"></div>
     
    </section>
    <!-- end of main  -->



<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>




</body>  
</html>


<?php
$username = filter_input(INPUT_POST, 'username');
$name = filter_input(INPUT_POST, 'name');
$password = filter_input(INPUT_POST, 'password');





if (!empty($username)){
if (!empty($password)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "food_order";




// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO users (username,name,password)
values ('$username','$name','$password')";


if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "Password should not be empty";
die();
}
}
else{
echo "Username should not be empty";
die();
}
?>