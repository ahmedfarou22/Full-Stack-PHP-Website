<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/admin_style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>
    

<!-- =================================Head========================================= -->
<?php include 'builder/hero.php';?>


<!-- =============================================================Main Section=================================-->



    <section class="contact-s">
      <div class="container">
        <div class="contact">
          <form action="loginadmin.php" method="POST" name="signin-form"> 
            <label for="fname">Username</label>
           
            <input type="text" id="fname" name="txt_uname" placeholder="Enter Admin's username">
            <!-- <input type="text" class="textbox" id="txt_uname" name="txt_uname" placeholder="Username" /> -->
        
            <label for="lname">Password</label>
            <input type="text" id="lname" name="txt_pwd" placeholder="Enter Admin's Password">
            <!-- <input type="password" class="textbox" id="txt_uname" name="txt_pwd" placeholder="Password"/> -->
            


  
            <input type="submit" name="but_submit" value="Submit" class="btn" style="padding: 1%;">
            <!-- <input type="submit" value="Submit" name="but_submit" id="but_submit" /> -->
          </form>
        </div>
    </section>





<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>






</body>
</html>


<?php
session_start();
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$dbname = "food_order"; 

$con = mysqli_connect($host, $user, $password,$dbname);

if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
?>

<?php

if(isset($_POST['but_submit'])){

    $uname = mysqli_real_escape_string($con,$_POST['txt_uname']);
    $password = mysqli_real_escape_string($con,$_POST['txt_pwd']);

    if ($uname != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from users where username='".$uname."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['uname'] = $uname;
            header('Location: index.php');
            // echo "hell yeah";
        }else{
            echo "Invalid username and password";
        }

    }

}
?>


