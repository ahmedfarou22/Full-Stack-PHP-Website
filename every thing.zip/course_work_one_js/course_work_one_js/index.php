<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>




<!-- =================================Head========================================= -->
<?php

include 'builder/nav.php';
include 'builder/hero.php';
?>
    
   

<!-- =============================================================Main Section=================================-->
   
    <!-- gallary section  -->
    <section class="gallary">
      <div class="container">
        <h2 class="text-center">Gallary</h2>

        <div class="img"><img src="imges/1.jpg" alt="pic 1" width="100%"></div>
        <div class="img"><img src="imges/2.jpg" alt="pic 1" width="100%"></div>
        <div class="img"><img src="imges/3.jpg" alt="pic 1" width="100%"></div>
        <div class="img"><img src="imges/4.jpg" alt="pic 1" width="100%"></div>
        <div class="img"><img src="imges/5.jpg" alt="pic 1" width="100%"></div>
        <div class="img"><img src="imges/6.jpg" alt="pic 1" width="100%"></div>
        
        <div class="clear-fix"></div>
        <div class="clear-fix"></div>
      
      </div>

    </section>
    <!-- end of gallary  -->




    <!-- call to action section  -->
    <section class="action">
      <div class="container">
       
        <div class="video">
          <video width="320" height="240" controls play>
            <source src="imges/video.mp4" type="video/mp4">
          </video>
        </div>

        <div class="btn-div">
          <a href="menu.php">
          <button class="btn">Order Now</button>
          </a>
        </div>

        <div class="clear-fix"></div>
      </div>
    </section>
    <!-- end of action  -->






<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>


  </body>
</html>