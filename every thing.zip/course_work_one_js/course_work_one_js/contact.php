<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact US</title> 
    <link rel="stylesheet" href="css/style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script> 
  </head>
  <body>


<!-- =================================Head========================================= -->
<?php

include 'builder/nav.php';
include 'builder/hero.php';
?>
    
   

<!-- =============================================================Main Section=================================-->
  

    <!-- start of contact  --><!-- ---------------------------------------------------------------------------------------------------- -->
    <section class="contact-s">
      <div class="container">
        <div class="contact">
          <form action="contact.php" method="POST" name="contact_us" onsubmit="return validateContact()">  
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="first_name" placeholder="Enter Your First Name">
        
            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="last_name" placeholder="Enter Your Last Name">
            
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder=" Enter Your Email">
        
            <label for="subject">Subject</label>
            <input id="subject" type="text" name="subject" style="height:200px">

  
            <input type="submit" name="submit" value="Submit" class="btn" style="padding: 1%;">
          </form>
        </div>
    </section>
    <!-- end of contact  --><!-- ---------------------------------------------------------------------------------------------------- -->







<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>




  </body>
</html>



<!-- ====================================================================================PHP AND BACK END ACTIONS======================================= -->





<?php


$first_name = filter_input(INPUT_POST, 'first_name');
$last_name = filter_input(INPUT_POST, 'last_name');
$email = filter_input(INPUT_POST, 'email');
$subject = filter_input(INPUT_POST, 'subject');


if (!empty($first_name)){
if (!empty($email)){


$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "food_order";




// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO menu_table (first_name,last_name,email,subject)
values ('$first_name','$last_name','$email','$subject')";


if ($conn->query($sql)){
echo "Thank You";
}
else{
echo "eroor";
}
$conn->close();
}
}
else{
echo "last name should not be empty";
die();
}
}
else{
echo "first name should not be empty";
die();
}
?>