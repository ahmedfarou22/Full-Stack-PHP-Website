<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title> 
    <link rel="stylesheet" href="css/style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>

<!-- =================================Head========================================= -->
<?php

include 'builder/nav.php';
include 'builder/hero.php';
?>
    
   

<!-- =============================================================Main Section=================================-->
    <section class="menu">
      <div class="container">
        <h2 class="text-center">Menu</h2>
        
        <div class="menu-it">
          
          <div class="food-menu-img">
              <img src="imges/m1.jpg" alt="Chicke Hawain Pizza" width="100%" style="border-radius: 15px;">
          </div>

          <div class="food-menu-desc">
              <h4>Tamya</h4>
              <p class="food-price">20 EGP</p>
              <p class="food-detail">
                  Made with organic ingredents
              </p>
              <br>

              <a href="ordert.php" class="btn">Order Now</a>
          </div>
        </div>


        <div class="menu-it">
          
          <div class="food-menu-img">
              <img src="imges/m2.jpg" alt="Chicke Hawain Pizza" width="100%" style="border-radius: 15px;">
          </div>

          <div class="food-menu-desc">
              <h4>Fool</h4>
              <p class="food-price">30 EGP</p>
              <p class="food-detail">
                Made with organic ingredents
              </p>
              <br>

              <a href="orderfool.php" class="btn">Order Now</a>
          </div>
        </div>
        <div class="menu-it">
          
          <div class="food-menu-img">
              <img src="imges/m3.jpg" alt="Chicke Hawain Pizza" width="100%" style="border-radius: 15px; ">
          </div>

          <div class="food-menu-desc">
              <h4>french fries</h4>
              <p class="food-price">35 EGP</p>
              <p class="food-detail">
                Made with organic ingredents
              </p>
              <br>

              <a href="orderfri.php" class="btn">Order Now</a>
          </div>
        </div>
        <div class="menu-it">
          
          <div class="food-menu-img">
              <img src="imges/m4.jpg" alt="Chicke Hawain Pizza" width="100%" style="border-radius: 15px;">
          </div>

          <div class="food-menu-desc">
              <h4>Pizza</h4>
              <p class="food-price">70 EGP</p>
              <p class="food-detail">
                Made with organic ingredents
              </p>
              <br>

              <a href="orderp.php" class="btn">Order Now</a>
          </div>
        </div>
        
        
        <div class="clear-fix"></div>
        <div class="clear-fix"></div>
        <div class="clear-fix"></div>
      </div>
    </section>









<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>






  </body>
</html>