<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title> 
    <link rel="stylesheet" href="css\style.css"> <!-- I link my css here -->
    <script type="text/javascript" src="js.js"></script>  <!-- I link my java script here -->
  </head>
  <body>

      <!-- =================================Head========================================= -->
<?php

include 'builder/nav.php';
include 'builder/hero.php';
?>


    <!-- order  section  --><!-- ---------------------------------------------------------------------------------------------------- -->
    <section class="contact-s">
      <div class="container">
        <div class="contact">
          <h2 class="text-center text-white">Fill this form to confirm your order.</h2>
          <br>
          <br>
          <br>

              <fieldset style="border: none;">

                  <div class="food-menu-img">
                      <img src="imges/m4.jpg" alt="Chicke Hawain Pizza" width="100%" style="border-radius: 15px; margin-top: -30px; margin-bottom: 30px;">
                  </div>
  
                  <div class="food-menu-desc">
                      <h3>Pizza</h3>
                      <p class="food-price">70</p>
                      
                  </div>

              </fieldset>
              
      <section class="contact-s">
      <div class="container">
        <div class="contact">
          <form action="orderp.php" method="POST" name="order" onsubmit="return validateorder()"> 
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="first_name" placeholder="Enter Your First Name">
        
            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="last_name" placeholder="Enter Your Last Name">
            
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder=" Enter Your Email">
        
            <label for="Address">Address</label>
            <input id="Address" type="text" name="Address" style="height:100px">

  
            <input type="submit" name="submit" value="Order" class="btn" style="padding: 1%;">
          </form>
        </div>
    </section>

          </form>
        </div>
    </section>
    <!-- end of contact  --><!-- ---------------------------------------------------------------------------------------------------- -->








<!-- =================================Footer========================================= -->
<?php

include 'builder/footer.php';
?>




  </body>
</html>



<!-- ====================================================================================PHP AND BACK END ACTIONS======================================= -->



<?php
$food_name = "Pizza";
$price = "70";
$first_name = filter_input(INPUT_POST, 'first_name');
$last_name = filter_input(INPUT_POST, 'last_name');
$email = filter_input(INPUT_POST, 'email');
$Address = filter_input(INPUT_POST, 'Address');


if (!empty($first_name)){
if (!empty($email)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "food_order";




// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO order_tbl (food_name,first_name,last_name,email,Address,price)
values ('$food_name','$first_name','$last_name','$email','$Address','$price')";


if ($conn->query($sql)){
echo "Thank You";
}
else{
  echo "eroor";
}
$conn->close();
}
}
else{
echo "last name should not be empty";
die();
}
}
else{
echo "first name should not be empty";
die();
}
?>