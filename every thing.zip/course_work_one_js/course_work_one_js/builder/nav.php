<?php

    //  <!-- start of top nav --><!-- ---------------------------------------------------------------------------------------------------- -->
    echo'
        <section class="top_nav">
       <div class="container">
         <div class="logo">                
           <a href="http://localhost/course_work_one/" title="Logo">
           <img src="imges/logo.png" alt="Restaurant Logo" width="100%">
           </a>
         </div>
         
           <div class="menu-right">
           <ul>
               <li>
                   <a href="index.php">Home</a>
               </li>
               <li>
                   <a href="menu.php">Menu</a>
               </li>
               <li>
                   <a href="contact.php">Contact us</a>
           </ul>
         <div class="clear-fix"></div>
       </div>
       </div>
     </section>'
    //  <!-- end of top nav --><!-- ---------------------------------------------------------------------------------------------------- -->


?>