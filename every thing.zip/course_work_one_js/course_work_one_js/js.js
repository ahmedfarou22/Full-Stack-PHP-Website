// ===============================================================================contact validate========================================
function validateContact() {
  var x = document.forms["contact_us"]["first_name"].value;
  var y = document.forms["contact_us"]["last_name"].value;
  var z = document.forms["contact_us"]["email"].value;
  var a = document.forms["contact_us"]["subject"].value;
  if (x == "") {
    document.getElementById("fname").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("fname").style.border = "1px solid #CEA975";}

// ----------------------

  if (y == "") {
    document.getElementById("lname").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("lname").style.border = "1px solid #CEA975";}

// ----------------------
  if (z == "") {
    document.getElementById("email").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("email").style.border = "1px solid #CEA975";}


// ----------------------
  if (a==""){
    document.getElementById("subject").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("subject").style.border = "1px solid #CEA975";}
}


// ===============================================================================order validate========================================
function validateorder() {
  var x = document.forms["order"]["first_name"].value;
  var y = document.forms["order"]["last_name"].value;
  var z = document.forms["order"]["email"].value;
  var a = document.forms["order"]["Address"].value;
  if (x == "") {
    document.getElementById("fname").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("fname").style.border = "1px solid #CEA975";}

// ----------------------

  if (y == "") {
    document.getElementById("lname").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("lname").style.border = "1px solid #CEA975";}

// ----------------------
  if (z == "") {
    document.getElementById("email").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("email").style.border = "1px solid #CEA975";}


// ----------------------
  if (a==""){
    document.getElementById("Address").style.border = "1px solid #E54059";
    return false;
  }
  else{document.getElementById("Address").style.border = "1px solid #CEA975";}
}

